#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <random>
#include <omp.h>

using namespace std;

const double CONFIDENCE_LEVEL = 0.95;

/* ---------- Monte Carlo Function ---------- */
void monteCarlo(bool parallel, int threads,
                double portfolioValue,
                const vector<double> &allocations,
                int numSimulations, double T,
                double &VaR, double &ES, double &time_taken)
{
    double S0 = 100.0, mu = 0.05, sigma = 0.2;
    vector<double> losses(numSimulations);

    double start = omp_get_wtime();

    if (!parallel)  // SERIAL
    {
        mt19937 gen(42);
        normal_distribution<double> dist(0.0, 1.0);

        for (int i = 0; i < numSimulations; i++)
        {
            double final_value = 0.0;
            for (double w : allocations)
            {
                double Z = dist(gen);
                double ST = S0 * exp((mu - 0.5 * sigma * sigma) * T +
                                     sigma * sqrt(T) * Z);
                final_value += w * portfolioValue * (ST / S0);
            }
            losses[i] = portfolioValue - final_value;
        }
    }
    else  // PARALLEL
    {
        omp_set_num_threads(threads);

        #pragma omp parallel
        {
            mt19937 gen(42 + omp_get_thread_num());
            normal_distribution<double> dist(0.0, 1.0);

            #pragma omp for
            for (int i = 0; i < numSimulations; i++)
            {
                double final_value = 0.0;
                for (double w : allocations)
                {
                    double Z = dist(gen);
                    double ST = S0 * exp((mu - 0.5 * sigma * sigma) * T +
                                         sigma * sqrt(T) * Z);
                    final_value += w * portfolioValue * (ST / S0);
                }
                losses[i] = portfolioValue - final_value;
            }
        }
    }

    sort(losses.begin(), losses.end());

    int var_index = static_cast<int>((1.0 - CONFIDENCE_LEVEL) * numSimulations);
    VaR = losses[var_index];

    ES = 0.0;
    for (int i = 0; i <= var_index; i++)
        ES += losses[i];
    ES /= (var_index + 1);

    time_taken = omp_get_wtime() - start;
}

/* ---------- MAIN ---------- */
int main()
{
    cout << "$ ./simulate_portfolio\n";
    cout << "------------------------------------------------------------\n";
    cout << "Portfolio Monte Carlo Simulation\n";
    cout << "------------------------------------------------------------\n";

    string mode;
    cout << "Execution mode (serial/parallel): ";
    cin >> mode;
    bool parallel = (mode == "parallel");

    double portfolioValue;
    cout << "Total portfolio value: ";
    cin >> portfolioValue;

    int numAssets;
    cout << "Number of assets: ";
    cin >> numAssets;

    vector<double> allocations(numAssets);
    double total = 0.0;

    for (int i = 0; i < numAssets; i++)
    {
        cout << "Allocation % for Asset " << (i+1) << ": ";
        cin >> allocations[i];
        allocations[i] /= 100.0; // convert to fraction
        total += allocations[i];
    }

    if (fabs(total - 1.0) > 1e-6)
    {
        cerr << "Error: Allocations must sum to 100%.\n";
        return 1;
    }

    int numSimulations;
    cout << "Number of simulations: ";
    cin >> numSimulations;

    double T;
    cout << "Time period (years): ";
    cin >> T;

    double VaR, ES, time_taken;

    if (!parallel)
    {
        // SERIAL MODE
        monteCarlo(false, 1, portfolioValue, allocations, numSimulations, T, VaR, ES, time_taken);
        cout << "\n===== SERIAL RESULTS =====\n";
        cout << "Value at Risk (VaR): " << VaR << endl;
        cout << "Expected Shortfall : " << ES << endl;
        cout << "Time Taken (Serial): " << time_taken << " seconds\n";
    }
    else
    {
        // SERIAL BASELINE
        double serial_VaR, serial_ES, serial_time;
        monteCarlo(false, 1, portfolioValue, allocations, numSimulations, T,
                   serial_VaR, serial_ES, serial_time);

        cout << "\n===== SERIAL BASELINE =====\n";
        cout << "VaR: " << serial_VaR << endl;
        cout << "ES : " << serial_ES << endl;
        cout << "Time (Serial): " << serial_time << " seconds\n";

        // PARALLEL MODE
        monteCarlo(true, 4, portfolioValue, allocations, numSimulations, T, VaR, ES, time_taken);

        cout << "\n===== PARALLEL RESULTS (4 threads) =====\n";
        cout << "VaR: " << VaR << endl;
        cout << "ES : " << ES << endl;
        cout << "Time (Parallel): " << time_taken << " seconds\n";
        cout << "Speedup: " << serial_time / time_taken << "x\n";
    }

    cout << "------------------------------------------------------------\n";
    cout << "Simulation complete.\n";
    cout << "$\n";

    return 0;
}

